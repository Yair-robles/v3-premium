# V3 Premium Service — copia de la página pública

## Abrir
Extrae el ZIP y abre index.html en tu navegador. Para servirlo localmente puedes ejecutar:

    python -m http.server 8000

Después visita http://localhost:8000.

## Publicar en tu hosting
Sube index.html y las carpetas img y videos a la raíz pública (por ejemplo, public_html). Conserva la estructura de carpetas.

## Editar
El HTML, CSS personalizado y JavaScript están en index.html. No requiere compilación ni instalación de paquetes.

## Alcance
Incluye la página pública, imágenes y video. No incluye el sistema administrativo, credenciales ni base de datos. El contador de vehículos no consulta la API original.

Tailwind CSS, Google Fonts, la imagen BMW de Unsplash y el mapa de Google se cargan desde servicios externos y requieren Internet. Los botones de WhatsApp, teléfono y administrador mantienen los destinos del negocio original. Cambia estos datos antes de utilizarla para otro negocio.
